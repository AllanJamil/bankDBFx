create definer = supergruppen@`%` trigger UpdateHistory
    after UPDATE
    on Account
    for each row
begin
        declare transAmount double ;
    if (new.balance != old.balance) then
    set transAmount =new.balance-old.Balance;
	insert into History (accountId, balance,transactionAmount) values (old.id, new.balance,transAmount);
    end If;
    end;

