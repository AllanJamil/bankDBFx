create
    definer = supergruppen@`%` procedure UpdateCustomerInfo(IN customerIdIN int, IN newFirstNameIN varchar(100),
                                                            IN newLastNameIN varchar(100), IN newPinIN varchar(4))
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	ROLLBACK;
	select ('SQLEXCEPTION occurred, rollback done') as error; 
END;
	start transaction;
UPDATE Customer
SET 
firstName = newFirstNameIN,
lastName = newLastNameIN,
pin = newPinIN
WHERE 
id = customerIdIN;
commit;
END;

