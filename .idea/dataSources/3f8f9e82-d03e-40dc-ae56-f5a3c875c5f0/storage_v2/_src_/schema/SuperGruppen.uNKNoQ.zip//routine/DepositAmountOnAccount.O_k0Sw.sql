create
    definer = supergruppen@`%` procedure DepositAmountOnAccount(IN accountIdIN int, IN amountIN int)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	ROLLBACK;
	select ('SQLEXCEPTION occurred, rollback done') as error; 
END;
	start transaction;
UPDATE Account
SET 
balance = balance + amountIN 
WHERE 
id = accountIdIN;
commit;
END;

