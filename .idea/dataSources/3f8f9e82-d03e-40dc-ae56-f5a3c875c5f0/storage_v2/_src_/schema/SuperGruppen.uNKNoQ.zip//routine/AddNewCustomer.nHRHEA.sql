create
    definer = supergruppen@`%` procedure AddNewCustomer(IN firstNameIN varchar(100), IN lastNameIN varchar(100),
                                                        IN pinIN varchar(4))
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	ROLLBACK;
	select ('SQLEXCEPTION occurred, rollback done') as error;
END;
	start transaction;
insert into Customer(firstName, lastName, pin) VALUES (firstNameIN, lastNameIN, pinIN);
		commit;
END;

