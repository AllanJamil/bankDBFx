create
    definer = supergruppen@`%` procedure CloseAccountForCustomer(IN accountIdIN int, IN customerIdIN int)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
	ROLLBACK;
	select ('SQLEXCEPTION occurred, rollback done') as error; 
END;
	start transaction;
    DELETE FROM Account
    WHERE id = accountIdIN AND customerId = customerIdIN;
    commit;
END;

