create
    definer = supergruppen@`%` procedure ChangeInterestRateOnAccount(IN accountIdIN int, IN newInterestRate double)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	ROLLBACK;
	select ('SQLEXCEPTION occurred, rollback done') as error; 
END;
	start transaction;
UPDATE Account
SET 
interestRate = newInterestRate
WHERE 
id = accountIdIN;
commit;
END;

