create
    definer = supergruppen@`%` procedure AddNewAccountForCustomer(IN customerIdIN int, IN balanceIN double, IN interestRateIN double)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	ROLLBACK;
	select ('SQLEXCEPTION occurred, rollback done') as error; 
END;
	start transaction;
insert into Account(customerId, Balance, interestRate) VALUES (customerIdIN, balanceIN, interestRateIN);
		commit;
END;

