create
    definer = supergruppen@`%` procedure AddNewLoan(IN accountIdIN int, IN balanceIN double, IN interestRateIN double,
                                                    IN paymentIntervalIN int)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	ROLLBACK;
	select ('SQLEXCEPTION occurred, rollback done') as error; 
END;
	start transaction;
insert into Loan(balance, interestRate, paymentInterval, accountId) VALUES (balanceIN, interestRateIN, paymentIntervalIN, accountIdIN);
		commit;
END;

