create
    definer = supergruppen@`%` procedure DeleteCustomer(IN firstNameIN varchar(100), IN lastNameIN varchar(100))
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
	ROLLBACK;
	select ('SQLEXCEPTION occurred, rollback done') as error; 
END;
	start transaction;
    DELETE FROM Customer
    WHERE firstName = firstNameIN AND lastName = lastNameIN;
    commit;
END;

