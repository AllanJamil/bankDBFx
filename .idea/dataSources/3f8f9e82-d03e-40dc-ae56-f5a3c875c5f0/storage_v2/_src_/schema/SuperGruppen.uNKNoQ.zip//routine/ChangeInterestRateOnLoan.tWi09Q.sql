create
    definer = supergruppen@`%` procedure ChangeInterestRateOnLoan(IN accountIdIN int, IN newInterestRate double)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	ROLLBACK;
	select ('SQLEXCEPTION occurred, rollback done') as error; 
END;
	start transaction;
UPDATE Loan
SET 
interestRate = newInterestRate
WHERE 
accountId = accountIdIN;
commit;
END;

