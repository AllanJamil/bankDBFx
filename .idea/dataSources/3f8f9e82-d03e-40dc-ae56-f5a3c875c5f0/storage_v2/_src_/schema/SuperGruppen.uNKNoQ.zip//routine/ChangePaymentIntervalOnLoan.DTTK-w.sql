create
    definer = supergruppen@`%` procedure ChangePaymentIntervalOnLoan(IN accountIdIN int, IN newPaymentInterval int)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
	ROLLBACK;
	select ('SQLEXCEPTION occurred, rollback done') as error; 
END;
	start transaction;
UPDATE Loan
SET paymentInterval = newPaymentInterval
WHERE 
accountId = accountIdIN;
commit;
END;

