create
    definer = supergruppen@`%` procedure verifyCustomer(IN pinCode int)
begin
    select * from Customer c where c.pin=pinCode;
end;

