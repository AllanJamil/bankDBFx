create
    definer = supergruppen@`%` procedure DeleteCustomerByID(IN customerIdIN int)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
	ROLLBACK;
	select ('SQLEXCEPTION occurred, rollback done') as error; 
END;
	start transaction;
    DELETE FROM Customer
    WHERE id = customerIdIN;
    commit;
END;

