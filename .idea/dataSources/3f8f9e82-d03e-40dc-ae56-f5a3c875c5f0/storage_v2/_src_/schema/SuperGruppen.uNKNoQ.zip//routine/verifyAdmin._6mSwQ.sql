create
    definer = supergruppen@`%` procedure verifyAdmin(IN username varchar(50), IN password varchar(50))
begin
    select * from AdminUser c where c.username=username and c.password=password;
end;

